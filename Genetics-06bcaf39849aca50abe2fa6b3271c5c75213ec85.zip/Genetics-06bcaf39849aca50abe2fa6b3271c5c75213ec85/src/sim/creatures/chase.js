import { resolveTicksPerSecond } from '../utils/resolvers.js';

const resolveNeedMeterBase = (value) => (Number.isFinite(value) && value > 0 ? value : 1);

const resolveThreshold = (value, fallback) => {
  if (!Number.isFinite(value)) {
    return fallback;
  }
  return Math.min(1, Math.max(0, value));
};

const resolveChaseDistance = (value, fallback) =>
  Number.isFinite(value) ? Math.max(0, value) : fallback;

/**
 * Converts a time value in seconds to ticks.
 */
const resolveTimeTicks = (seconds, fallbackSeconds, ticksPerSecond) => {
  const tps = Number.isFinite(ticksPerSecond) ? ticksPerSecond : 60;
  const value = Number.isFinite(seconds) ? seconds : fallbackSeconds;
  return Math.max(0, Math.trunc(value * tps));
};

const resolveTargetingRange = (config) => {
  if (Number.isFinite(config?.creatureTargetingRange)) {
    return Math.max(0, config.creatureTargetingRange);
  }
  if (Number.isFinite(config?.creaturePerceptionRange)) {
    return Math.max(0, config.creaturePerceptionRange);
  }
  return 0;
};

const getStaminaRatio = (creature, baseStamina) => {
  const stamina = creature?.meters?.stamina;
  const ratio = Number.isFinite(stamina) ? stamina / baseStamina : 0;
  return Math.min(1, Math.max(0, ratio));
};

const ensureChaseState = (creature) => {
  if (!creature.chase) {
    creature.chase = {
      status: 'idle',
      targetId: null,
      preySpecies: null,
      lastSeenTick: null,
      lastKnownPosition: null,
      distance: null,
      restTicks: 0,
      lastOutcome: null,
      lastOutcomeTick: null,
      lastTargetId: null,
      lastTargetPosition: null
    };
  }
  return creature.chase;
};

/**
 * Finds a creature by ID using spatial index for O(1) lookup,
 * or falls back to linear scan if no spatial index.
 */
const findTargetById = (id, creatures, spatialIndex) => {
  if (!Number.isFinite(id)) return null;
  
  // Use spatial index if provided and has creatures
  if (spatialIndex && spatialIndex.creatureCount > 0) {
    return spatialIndex.getById(id);
  }
  
  // Fall back to linear scan
  if (!Array.isArray(creatures)) return null;
  for (const creature of creatures) {
    if (creature?.id === id) {
      return creature;
    }
  }
  return null;
};

const concludeChase = ({ chase, config, metrics, tick, outcome, target, chaserSpecies }) => {
  const tps = resolveTicksPerSecond(config);
  const restTicks = resolveTimeTicks(config?.creatureChaseRestTime, 0.1, tps);
  chase.status = 'resting';
  if (outcome === 'caught') {
    chase.lastTargetId = Number.isFinite(chase.targetId) ? chase.targetId : (target?.id ?? null);
    if (target?.position) {
      chase.lastTargetPosition = {
        x: target.position.x,
        y: target.position.y
      };
    } else if (chase.lastKnownPosition) {
      chase.lastTargetPosition = {
        x: chase.lastKnownPosition.x,
        y: chase.lastKnownPosition.y
      };
    } else {
      chase.lastTargetPosition = null;
    }
  } else {
    chase.lastTargetId = null;
    chase.lastTargetPosition = null;
  }
  chase.targetId = null;
  chase.preySpecies = null;
  chase.lastKnownPosition = null;
  chase.distance = null;
  chase.restTicks = restTicks;
  chase.lastOutcome = outcome;
  chase.lastOutcomeTick = tick;
  if (metrics) {
    if (outcome === 'caught') {
      metrics.chaseSuccesses = (metrics.chaseSuccesses ?? 0) + 1;
    } else {
      metrics.chaseLosses = (metrics.chaseLosses ?? 0) + 1;
    }
    if (chaserSpecies) {
      if (outcome === 'caught') {
        if (
          metrics.chaseSuccessesBySpecies &&
          metrics.chaseSuccessesBySpecies[chaserSpecies] !== undefined
        ) {
          metrics.chaseSuccessesBySpecies[chaserSpecies] += 1;
        }
      } else if (
        metrics.chaseLossesBySpecies &&
        metrics.chaseLossesBySpecies[chaserSpecies] !== undefined
      ) {
        metrics.chaseLossesBySpecies[chaserSpecies] += 1;
      }
    }
  }
};

export function updateCreatureChase({ creatures, config, metrics, tick, spatialIndex }) {
  if (!Array.isArray(creatures)) {
    return;
  }
  const tps = resolveTicksPerSecond(config);
  const baseStamina = resolveNeedMeterBase(config?.creatureBaseStamina);
  const stopThreshold = resolveThreshold(config?.creatureChaseStopThreshold, 0.25);
  const loseDistance = resolveChaseDistance(
    config?.creatureChaseLoseDistance,
    resolveTargetingRange(config) * 1.25
  );
  const catchDistance = resolveChaseDistance(config?.creatureChaseCatchDistance, 0.6);
  const loseTicks = resolveTimeTicks(config?.creatureChaseLoseTime, 0.1, tps);

  for (const creature of creatures) {
    if (!creature?.position) {
      continue;
    }
    const chase = ensureChaseState(creature);
    if (chase.restTicks > 0) {
      chase.restTicks -= 1;
      chase.status = 'resting';
      if (chase.restTicks <= 0) {
        chase.status = 'idle';
      }
    }

    if (!Number.isFinite(chase.targetId)) {
      continue;
    }

    const staminaRatio = getStaminaRatio(creature, baseStamina);
    if (staminaRatio < stopThreshold) {
      concludeChase({
        chase,
        config,
        metrics,
        tick,
        outcome: 'exhausted',
        chaserSpecies: creature.species
      });
      continue;
    }

    const target = findTargetById(chase.targetId, creatures, spatialIndex);
    if (!target?.position) {
      concludeChase({
        chase,
        config,
        metrics,
        tick,
        outcome: 'lost',
        chaserSpecies: creature.species
      });
      continue;
    }

    const dx = target.position.x - creature.position.x;
    const dy = target.position.y - creature.position.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    chase.distance = distance;

    if (distance <= catchDistance) {
      concludeChase({
        chase,
        config,
        metrics,
        tick,
        outcome: 'caught',
        target,
        chaserSpecies: creature.species
      });
      continue;
    }

    if (distance <= loseDistance) {
      chase.status = 'pursuing';
      chase.lastSeenTick = tick;
      chase.lastKnownPosition = {
        x: target.position.x,
        y: target.position.y
      };
      continue;
    }

    const lastSeenTick = Number.isFinite(chase.lastSeenTick) ? chase.lastSeenTick : tick;
    const missingTicks = Math.max(0, tick - lastSeenTick);
    if (missingTicks >= loseTicks) {
      concludeChase({
        chase,
        config,
        metrics,
        tick,
        outcome: 'lost',
        target,
        chaserSpecies: creature.species
      });
      continue;
    }

    chase.status = 'losing';
  }
}

export function getChaseTarget(creature, creatures, spatialIndex) {
  if (!creature?.chase || !Number.isFinite(creature.chase.targetId)) {
    return null;
  }
  return findTargetById(creature.chase.targetId, creatures, spatialIndex);
}

export function startCreatureChase({ creature, target, metrics, config, tick }) {
  if (!creature || !target) {
    return false;
  }
  const chase = ensureChaseState(creature);
  if (chase.restTicks > 0) {
    return false;
  }
  const baseStamina = resolveNeedMeterBase(config?.creatureBaseStamina);
  const startThreshold = resolveThreshold(config?.creatureChaseStartThreshold, 0.6);
  const staminaRatio = getStaminaRatio(creature, baseStamina);
  if (staminaRatio < startThreshold) {
    return false;
  }
  chase.status = 'pursuing';
  chase.targetId = target.id;
  chase.preySpecies = target.species ?? null;
  chase.lastSeenTick = tick;
  chase.lastKnownPosition = {
    x: target.position.x,
    y: target.position.y
  };
  chase.distance = null;
  chase.lastOutcome = null;
  chase.lastOutcomeTick = null;
  chase.lastTargetId = null;
  chase.lastTargetPosition = null;
  if (metrics) {
    metrics.chaseAttempts = (metrics.chaseAttempts ?? 0) + 1;
    if (
      metrics.chaseAttemptsBySpecies &&
      metrics.chaseAttemptsBySpecies[creature.species] !== undefined
    ) {
      metrics.chaseAttemptsBySpecies[creature.species] += 1;
    }
  }
  return true;
}
