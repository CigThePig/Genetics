Active track: Maintenance — Per-Species Metrics Expansion
Path: tracks/2026-02-01-track-maintenance-per-species-metrics/
Current phase: Phase 1 — Add per-species metrics, summary keys, and UI grouping (complete)
Next task: Manual: verify grouped metrics update during sim.
Last updated: 2026-02-01
Notes: Maintenance work requested to add per-species metrics counters and UI grouping.
