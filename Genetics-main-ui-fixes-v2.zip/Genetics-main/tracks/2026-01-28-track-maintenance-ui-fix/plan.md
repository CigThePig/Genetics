# Plan — Maintenance: UI Config Panel Fixes

## Recon Summary
- **Files likely to change:**
  - `src/ui/config-panel.js` (input rendering, categories, control types, power features).
  - `src/sim/config.js` (configMeta coverage, boolean types, UI schema hints).
  - `src/styles.css` (toggle/slider styling, responsive layout, details/summary styling).
  - `src/main.js` (only if batch apply or reset hooks are required).
- **Key invariants:**
  - Do not change simulation behavior or defaults (no simConfig edits).
  - Determinism preserved; UI writes only.
  - Boolean flags must write true/false (no 0/1 for boolean types).
- **Cross-module side effects:**
  - Config panel renders based on configMeta; missing categories can hide knobs.
  - Reset logic relies on simConfig defaults; ensure defaults remain unchanged.
- **Tick order impact:** None (UI-only changes).
- **Observability impact:** None required.
- **File rules impact:** No new systems expected.
- **Risks/regressions:** Wrong type mapping, missing category rendering, mobile layout regressions.
- **Verification commands/checks:** Manual UI checks per phase; optional `npm run dev` for inspection.

---

## Deviation Note (2026-02-04)
- Added Phase 4 to capture requested UI polish (graphs bottom sheet handle/FAB, config section persistence, inspector clear button) that extends beyond `context/UI-FIX` while remaining UI-only and determinism-safe.

---

## Phase 1 — Boolean trap + hidden knob exposure

### Tasks
- [x] Audit `configMeta` for boolean feature flags and set `type: 'boolean'` while removing numeric min/max/step.
- [x] Update config panel rendering to use checkboxes/toggles for boolean type and write true/false.
- [x] Ensure panel update path sets `checked` from config for boolean inputs.
- [x] Add missing categories to the config panel and add fallback category handling.
- [x] Add configMeta entries for verified hidden primitive knobs (numbers/booleans/selects only).
- [ ] ✅ Reminder: update `/context/repo-map.md` if files/roles change.

### Files touched
- `src/ui/config-panel.js`
- `src/sim/config.js`
- `src/styles.css` (only if checkbox styling is needed)
- `src/main.js` (only if wiring changes are needed)

### Verification checklist
- [ ] Run dev server and open config panel.
- [ ] Toggle a boolean feature off; confirm the config writes `false` and the feature disables.
- [ ] Confirm no boolean inputs write 0/1.
- [ ] Confirm newly exposed hidden knobs appear in intended categories.
- [ ] Confirm categories like world/memory/metrics/rendering are visible.

### Stop point
- Pause after manual UI checks; do not proceed to Phase 2 without review.

---

## Phase 2 — UI reorg + real controls + descriptions

### Tasks
- [x] Extend configMeta with `description`, `unit`, `control`, and `advanced` hints from verified doc.
- [x] Render categories as collapsible sections with readable headers.
- [x] Render boolean toggles, selects, sliders + number inputs based on configMeta hints.
- [x] Show default values and highlight changed values.
- [x] Improve mobile layout (stacked rows, larger controls).
- [ ] ✅ Reminder: update `/context/repo-map.md` if files/roles change.

### Files touched
- `src/ui/config-panel.js`
- `src/sim/config.js`
- `src/styles.css`
- `src/main.js` (only if needed for reset hooks)

### Verification checklist
- [ ] Boolean flags render as toggles.
- [ ] Sliders appear for bounded numeric knobs.
- [ ] Descriptions/units match verified doc intent.
- [ ] Layout stacks cleanly on narrow viewports.

### Stop point
- Pause after manual UI checks; do not proceed to Phase 3 without review.

---

## Phase 3 — Power tuning + structured knob editors

### Tasks
- [x] Add search/filter over label/key/description.
- [x] Add favorites/pinning with localStorage persistence.
- [x] Implement preset export/import with validation.
- [x] Add JSON editor for structured knobs with validate/apply flow.
- [x] Add section-level reset per category.
- [ ] ✅ Reminder: update `/context/repo-map.md` if files/roles change.

### Files touched
- `src/ui/config-panel.js`
- `src/styles.css`
- `src/sim/config.js`
- `src/main.js` (optional for batch apply support)

### Verification checklist
- [ ] Search filters knobs correctly without breaking layout.
- [ ] Favorites persist across reloads.
- [ ] Export/import validates JSON and applies only known keys.
- [ ] JSON editor prevents invalid changes.
- [ ] Section reset restores defaults.

### Stop point
- Pause after manual UI checks; no further phases until review.

---

## Phase 4 — UI polish + panel usability

### Tasks
- [x] Persist config section collapse state and update toggle row layout hooks.
- [x] Add graphs bottom-sheet handle with drag open/close and a visibility callback.
- [x] Add Graphs FAB and sync its active state with panel visibility.
- [x] Add inspector clear-selection button with styling.
- [x] Update config/graphs/inspector styling for spacing, separators, toggles, and handle peek.
- [x] ✅ Reminder: update `/context/repo-map.md` if files/roles change.

### Files touched
- `src/ui/config-panel.js`
- `src/ui/graphs-panel.js`
- `src/ui/index.js`
- `src/ui/live-inspector.js`
- `src/styles.css`

### Verification checklist
- [ ] Config sections remember collapsed/open state after refresh.
- [ ] Graphs panel can be dragged open/closed and the Graphs FAB reflects visibility.
- [ ] Inspector clear button resets tracking and follow state.
- [ ] Toggle rows stay aligned on mobile widths.

### Stop point
- Pause after manual UI checks; confirm in review before additional scope.
