# Repo Map (Master Context Index)

Purpose:

- One-page index of important files and how they connect.
- Keeps planning accurate without dumping the whole repo into prompts.

Rules:

- Keep entries short (2–6 bullets).
- Update when files are added or roles change.

## Top-level

- AGENTS.md
  - Role: agent rules + constraints + workflow gates
- README.md
  - Role: repo landing page + quickstart + deployment summary
- LICENSE
  - Role: licensing terms (MIT)
- package.json
  - Role: npm scripts + dependencies
- package-lock.json
  - Role: dependency lockfile for npm ci
- vite.config.js
  - Role: Vite config with env-configured base path
- index.html
  - Role: app shell entry for Vite
- .gitignore
  - Role: ignore build output + node modules
- .editorconfig
  - Role: consistent whitespace + line endings across editors
- .eslintrc.cjs
  - Role: lint rules for catching bugs + unused code early
- .prettierrc.json, .prettierignore
  - Role: formatting defaults + excluded paths

## GitHub

- .github/workflows/deploy.yml
  - Role: GitHub Pages build + deploy pipeline
- .github/workflows/verify.yml
  - Role: CI gate for tests + build + lint/format checks

## Context

- context/README.md
  - Role: project overview, pillars, and workflow summary
- context/track-index.md
  - Role: the ordered roadmap packaged into track definitions
  - Used by: planning to create tracks consistently
- context/planning-checklist.md
  - Role: the ritual + prompts for creating tracks and phases safely
- context/repo-map.md
  - Role: canonical index of modules/files and their interactions
- context/product.md
  - Role: pillars, goals, scope boundaries
- context/architecture.md
  - Role: invariants (determinism, tick order, config, iteration order)
- context/workflow.md
  - Role: lifecycle rules (Track Index → Recon → Spec → Blueprint → Plan → Build → Verify → GC)
- context/tech-stack.md
  - Role: tools, build, deploy
- context/code-style.md
  - Role: module boundaries + file rules (new system=new file, max 600 LOC)
- context/active-track.md
  - Role: pointer to current track folder + current phase/task
- context/history.md
  - Role: append-only track summaries + verification notes

## Tracks

- tracks/YYYY-MM-DD-track-N-<slug>/
  - Contains: spec.md, blueprint.md, plan.md
  - Rule: scope must match Track Index for Track N unless explicitly overridden
- tracks/2026-01-19-track-0-repo-bootstrap/
  - Contains: Track 0 spec/blueprint/plan (Repo Bootstrap)
- tracks/2026-01-19-track-1-developer-visibility-control/
  - Contains: Track 1 spec/blueprint/plan (Developer Visibility & Control)
- tracks/2026-01-19-track-2-canvas-camera-inspection-skeleton/
  - Contains: Track 2 spec/blueprint/plan (Canvas + Camera + Inspection Skeleton)
- tracks/2026-01-21-track-3-world-grid-terrain-foundations/
  - Contains: Track 3 spec/blueprint/plan (World Grid & Terrain Foundations)
- tracks/2026-01-19-track-4-plant-economy-grass-stress-bushes-berries/
  - Contains: Track 4 spec/blueprint/plan (Plant Economy: Grass, Stress, Bushes, Berries)
- tracks/2026-01-19-track-5-plant-economy-recovery-rendering-metrics/
  - Contains: Track 5 spec/blueprint/plan (Plant Economy: Recovery, Rendering, Metrics)
- tracks/2026-01-19-track-6-creature-core-meters-stages-movement/
  - Contains: Track 6 spec/blueprint/plan (Creature Core: Meters, Stages, Movement)
- tracks/2026-01-19-track-6p5-canon-lock/
  - Contains: Track 6.5 spec/blueprint/plan (Canon Lock + Species Retrofit)
- tracks/2026-01-19-track-7-survival-actions-sprinting-death/
  - Contains: Track 7 spec/blueprint/plan (Survival Actions + Sprinting + Death)
- tracks/2026-01-24-track-8-food-web-perception-memory/
  - Contains: Track 8 spec/blueprint/plan (Food Web + Perception + Memory)
- tracks/2026-01-25-track-9-predation-chase-dynamics/
  - Contains: Track 9 spec/blueprint/plan (Predation + Chase Dynamics)
- tracks/2026-01-26-track-10-reproduction-loop-basic-genetics/
  - Contains: Track 10 spec/blueprint/plan (Reproduction Loop + Basic Genetics)
- tracks/2026-01-29-track-10p5-timebase-survival-visibility-map-scale/
  - Contains: Track 10.5 spec/blueprint/plan (Timebase + Survival + Visibility + Map Scale)
- tracks/2026-01-30-track-10p6-gender-pregnancy-birth/
  - Contains: Track 10.6 spec/blueprint/plan (Gender + Pregnancy + Birth)
- tracks/2026-02-01-track-maintenance-per-species-metrics/
  - Contains: Maintenance spec/blueprint/plan (Per-species metrics expansion)
- tracks/2026-01-27-track-maintenance-touch-gesture-guardrails/
  - Contains: Maintenance spec/blueprint/plan (Touch gesture guardrails)
- tracks/2026-01-28-track-maintenance-camera-change-callback/
  - Contains: Maintenance spec/blueprint/plan (Camera change callback)
- tracks/2026-01-22-track-maintenance-creature-render-pass/
  - Contains: Maintenance spec/blueprint/plan (Creature render pass)
- tracks/2026-01-23-track-maintenance-metrics-population/
  - Contains: Maintenance spec/blueprint/plan (Metrics population display)
- tracks/.gitkeep
  - Role: placeholder to keep the tracks directory in git

## Source

- src/main.js
  - Role: app entry; wires sim + renderer + UI
- src/app/settings.js
  - Role: settings persistence (seed, speed, toggles)
- src/sim/config.js
  - Role: centralized tunable config (terrain + plant scaffolding)
- src/sim/rng.js
  - Role: seeded RNG module for deterministic randomness
- src/sim/sim.js
  - Role: sim orchestration stub + RNG wiring
- src/sim/world-grid.js
  - Role: world grid data structure + terrain/grass/stress accessors
- src/sim/terrain-generator.js
  - Role: deterministic terrain blob generator for world grid initialization
- src/sim/terrain-effects.js
  - Role: terrain effects lookup table (friction, perception, plant cap)
- src/sim/species.js
  - Role: canonical species identifiers + deterministic spawn assignment
- src/sim/plants/grass.js
  - Role: grass regrowth update logic + summary stats
- src/sim/plants/bushes.js
  - Role: bush entity placement and berry pool summary updates
- src/sim/plants/carcasses.js
  - Role: carcass spawning, meat consumption, and decay updates
- src/sim/plants/index.js
  - Role: plant system orchestrator for sim ticks
- src/sim/plant-generator.js
  - Role: seeds initial grass patches for world generation
- src/sim/worker.js
  - Role: worker-ready sim stub interface for future worker-backed loop
- src/sim/metrics-factory.js
  - Role: creates default metrics objects for sim initialization and reset
- src/sim/utils/resolvers.js
  - Role: shared config resolver utilities (clampMeter, resolveRatio, resolveTicksPerSecond, etc.)
  - Used by: creatures/_, plants/_, intent, actions
- src/sim/utils/config.js
  - Role: safe deep-clone + deep-merge helpers for simulation config
  - Used by: sim/sim.js, main.js (config reset)
- src/sim/utils/config.js
  - Role: deep-clone + deep-merge helpers for sim config
  - Used by: sim.js, main.js
- src/sim/creatures/index.js
  - Role: re-export hub for all creature subsystems
- src/sim/creatures/death.js
  - Role: creature death conditions and removal
- src/sim/creatures/metabolism.js
  - Role: basal metabolism drains, sprint decisions, stamina regen
- src/sim/creatures/movement.js
  - Role: creature position updates, terrain collision, water avoidance
- src/sim/creatures/intent.js
  - Role: priority selection and intent decision-making
- src/sim/creatures/actions.js
  - Role: eating and drinking action execution
- src/sim/creatures/spawn.js
  - Role: initial creature creation, positioning, sex assignment
- src/sim/creatures/traits.js
  - Role: per-creature trait defaults derived from config
- src/sim/creatures/genetics.js
  - Role: genome defaults, inheritance, and genome-to-trait multipliers
- src/sim/creatures/food.js
  - Role: canonical diet preferences, food properties, and efficiency helpers
- src/sim/creatures/perception.js
  - Role: perception scanning for nearby food/water with terrain modifiers
- src/sim/creatures/alertness.js
  - Role: alertness and reaction delay updates driven by perception changes
- src/sim/creatures/memory.js
  - Role: memory records for food/water locations with decay and selection helpers
- src/sim/creatures/targeting.js
  - Role: deterministic predator target scoring helpers
- src/sim/creatures/chase.js
  - Role: chase state updates, stamina gating, and loss rules
- src/sim/creatures/combat.js
  - Role: predator attack execution and carcass spawning
- src/sim/creatures/herding.js
  - Role: flocking/herding behavior for herbivore creatures
- src/sim/creatures/reproduction.js
  - Role: deterministic reproduction loop + offspring spawning
- src/sim/creatures/life-stages.js
  - Role: shared life stage definitions and resolution (juvenile/adult/elder)
  - Used by: creatures/index.js, creatures/reproduction.js
- src/render/renderer.js
  - Role: canvas renderer that draws the view using camera state
- src/render/camera.js
  - Role: camera state + pan/zoom helpers for renderer/input
- src/input/index.js
  - Role: input system entry point with touch pan/pinch camera controls
- src/metrics/index.js
  - Role: metrics system entry point (FPS overlay + toggle support)
- src/ui/index.js
  - Role: touch-first UI shell (FPS toggle + status updates)
- src/ui/config-panel.js
  - Role: runtime config editor panel with category groupings
- src/ui/live-inspector.js
  - Role: creature inspection panel with real-time state display
- src/styles.css
  - Role: global styles with modern CSS design system

## Tests

- tests/sim.test.js
  - Role: Vitest smoke test for sim scaffold
- tests/genetics.test.js
  - Role: deterministic genetics mutation smoke test
- tests/creatures.test.js
  - Role: validates basal metabolism drains, life stages, reproduction, pregnancy
- tests/targeting.test.js
  - Role: validates predator target scoring determinism
- tests/carcasses.test.js
  - Role: validates carcass spawning, consumption, and decay
- tests/hunting.test.js
  - Role: validates combat mechanics and carcass spawning on kill
