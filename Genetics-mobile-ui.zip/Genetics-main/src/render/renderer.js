/**
 * Renderer
 * Re-exports enhanced renderer with polished terrain visuals
 */

export { createRenderer } from './renderer-enhanced.js';
