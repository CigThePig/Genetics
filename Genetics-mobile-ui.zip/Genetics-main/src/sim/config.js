/**
 * Simulation Configuration
 *
 * TIME VALUE CONVENTIONS (STANDARDIZED):
 * - ticksPerSecond: Number of simulation ticks per real second (default: 60)
 * - All time-based config values are in SECONDS
 * - Resolver functions convert seconds → ticks internally using ticksPerSecond
 * - Drain/regen rates are per-second rates, scaled by tickScale (1/ticksPerSecond)
 *
 * CATEGORIES:
 * - World: terrain, tiles, world size
 * - Plants: grass regrowth, bushes, berries
 * - Creatures: population, movement, needs, reproduction
 * - Genetics: genome defaults, mutation rates
 */
export const simConfig = {
  // === SIMULATION ===
  seed: 1,
  hotspotSeed: 1337,
  ticksPerSecond: 60,

  // === WORLD ===
  tileSize: 20,
  worldWidth: 120,
  worldHeight: 80,
  defaultTerrain: 'plains',
  waterTerrain: 'water',
  shoreTerrain: 'shore',
  terrainTypes: ['plains', 'forest', 'rock', 'sand', 'shore', 'water'],

  // Enhanced terrain generation (noise-based)
  terrainNoiseScale: 0.035, // Controls terrain feature size (smaller = larger features)
  terrainWaterLevel: -0.18, // Height threshold for water (-1 to 1)
  terrainShoreLevel: -0.08, // Height threshold for shore
  terrainRockThreshold: 0.72, // Roughness threshold for rock formation
  terrainForestMoisture: 0.58, // Moisture threshold for forest biome
  terrainSandMoisture: 0.32, // Moisture threshold below which sand appears

  // Legacy terrain settings (for fallback)
  terrainBlobCount: 72,
  terrainBlobMinRadius: 2,
  terrainBlobMaxRadius: 6,
  waterCorridorCount: 8,
  waterCorridorMinLength: 10,
  waterCorridorMaxLength: 22,
  waterCorridorWidth: 2,
  waterCorridorTurnChance: 0.35,

  // === PLANTS: GRASS ===
  grassCap: 1,
  grassRegrowthRate: 0.025, // per second (was 0.02 - slightly faster recovery)
  grassRegrowthDiminishPower: 1.5,
  grassInitialAmount: 0.25, // (was 0.2 - more starting food)
  grassPatchCount: 112,
  grassPatchMinRadius: 2,
  grassPatchMaxRadius: 7,
  grassPatchFalloffPower: 1.6,
  grassPatchBaseRatio: 0.15,
  grassStressThreshold: 0.15,
  grassStressIncrease: 0.02,
  grassStressRecoveryRate: 0.018, // (was 0.015 - faster stress recovery)
  grassStressRecoveryThreshold: 0.35,
  grassStressVisibleThreshold: 0.1,
  grassCoverageThreshold: 0.1,
  grassHotspotThreshold: 0.75,

  // === PLANTS: BUSHES ===
  bushCount: 96,
  bushInitialHealth: 0.85,
  bushBerryMax: 12,
  bushInitialBerries: 8, // (was 6 - more starting berries)
  bushRecoveryRate: 0.012, // (was 0.01 - slightly faster bush recovery)
  bushBerryRegenRate: 0.3, // (was 0.25 - faster berry regen)

  // === PLANTS: CARCASSES ===
  carcassBaseYield: 3.5, // (was 3.0 - more meat per kill keeps predators full longer)
  carcassMaxMeatPerCell: 6,
  carcassDecayRate: 0.012, // (was 0.015 - slower decay, carcass lasts longer)

  // === CREATURES: SPAWNING ===
  creatureCount: 80,
  creaturePredatorCount: 8, // (was 5 - more predators for better ecosystem pressure)
  creatureSpawnClusterSpread: 12,
  creatureSpawnClusterJitter: 4,

  // === CREATURES: MOVEMENT STYLE ===
  // Controls how creatures turn and commit to directions
  creatureMaxTurnRateRadPerSecond: 3.5, // ~200°/sec - smooth but responsive
  creatureWanderRetargetTimeMin: 0.8, // seconds before picking new wander heading
  creatureWanderRetargetTimeMax: 2.5, // seconds max before retarget
  creatureWanderTurnJitter: 0.4, // radians - noise only on retarget, not every tick
  creatureFleeMaxTurnMultiplier: 2.5, // faster turning when threatened

  // Long-range need search (when no target is perceived or remembered)
  creatureSearchRadiusMin: 12, // tiles
  creatureSearchRadiusMax: 90, // tiles
  creatureSearchRadiusGrowth: 1.35, // multiplier per failed attempt
  creatureSearchArriveDistance: 1.25, // tiles (distance to consider target reached)

  // === CREATURES: HERDING ===
  // Only herbivores (squares, circles) herd - predators hunt independently
  creatureHerdingEnabled: true,
  creatureHerdingRange: 14, // (was 12 - wider herding awareness)
  creatureHerdingThreatRange: 10, // (was 8 - better predator detection)
  creatureHerdingStrength: 0.025, // (was 0.02 - slightly tighter groups)
  creatureHerdingThreatStrength: 0.25, // (was 0.2 - stronger flee response)
  creatureHerdingMinGroupSize: 2,
  creatureHerdingSeparation: 2.0,
  creatureHerdingIdealDistance: 5,
  creatureHerdingAlignmentStrength: 0.4, // relative to base strength
  creatureHerdingComfortMin: 2.0, // inside comfort band, minimal steering
  creatureHerdingComfortMax: 4.5, // outside this, cohesion kicks in

  // === CREATURES: BASE STATS ===
  creatureBaseEnergy: 1,
  creatureBaseWater: 1,
  creatureBaseStamina: 1,
  creatureBaseHp: 1,
  creatureBaseSpeed: 10, // (was 9 - slightly faster base movement)

  // === CREATURES: PERCEPTION & ALERTNESS ===
  creaturePerceptionRange: 5, // (was 4 - better awareness)
  creaturePerceptionRangeMax: 8, // (was 7)
  creatureAlertnessBase: 0.6, // (was 0.55 - more alert)
  creatureReactionDelay: 0.033, // seconds (unchanged)

  // === CREATURES: TARGETING & CHASE ===
  creatureTargetingRange: 12, // (was 10 - predators can spot prey further)
  creatureTargetingDistanceWeight: 0.12,
  creatureTargetingPreferences: {
    triangle: { circle: 1, octagon: 0.85 },
    octagon: { square: 1 }
  },
  creatureChaseStartThreshold: 0.55, // (was 0.6 - start chasing with less stamina)
  creatureChaseStopThreshold: 0.2, // (was 0.25 - push harder before giving up)
  creatureChaseLoseDistance: 14, // (was 12 - longer chase persistence)
  creatureChaseLoseTime: 0.3, // (was 0.25 - more time before losing target)
  creatureChaseCatchDistance: 1.0,
  creatureChaseRestTime: 0.15, // (was 0.1 - slightly longer rest after chase)

  // === CREATURES: PREDATOR BEHAVIOR ===
  // When well-fed, predators patrol instead of constantly hunting
  creaturePredatorRestEnabled: true,
  creaturePredatorRestThreshold: 0.75, // (was 0.7 - rest slightly earlier)
  creaturePredatorHuntThreshold: 0.5, // (was 0.4 - start hunting sooner)
  creaturePredatorPatrolSpeed: 0.45, // (was 0.4 - slightly faster patrol)

  // === CREATURES: PACK BEHAVIOR ===
  // Predators form packs and patrol with waypoints
  creaturePackEnabled: true,
  creaturePackSpacing: 3.5, // distance between pack members
  creaturePredatorPatrolRadius: 25, // how far from home to patrol
  creaturePredatorPatrolRetargetTimeMin: 3, // seconds before new waypoint
  creaturePredatorPatrolRetargetTimeMax: 8, // seconds max before retarget

  // === CREATURES: MEMORY ===
  creatureMemoryMaxEntries: 12,
  creatureMemoryDecay: 0.018, // (was 0.02 - memories last slightly longer)
  creatureMemoryMinStrength: 0.05,
  creatureMemoryMergeDistance: 1.5,
  creatureMemoryVisitPenalty: 0.5,

  // === CREATURES: METABOLISM ===
  creatureBasalEnergyDrain: 0.007, // (was 0.008 - slightly slower drain)
  creatureBasalWaterDrain: 0.009, // (was 0.01 - slightly slower drain)
  creatureBasalStaminaDrain: 0.003, // (was 0.004 - slower passive stamina loss)

  // === CREATURES: SPRINT ===
  creatureSprintStartThreshold: 0.65, // (was 0.7 - sprint with slightly less stamina)
  creatureSprintStopThreshold: 0.35, // (was 0.4 - push sprinting further)
  creatureSprintSpeedMultiplier: 1.7, // (was 1.6 - faster sprinting)
  creatureSprintStaminaDrain: 0.25, // (was 0.3 - slower sprint drain = longer chases)
  creatureStaminaRegen: 0.2, // (was 0.18 - faster stamina recovery)

  // === CREATURES: REPRODUCTION ===
  creatureReproductionMinAge: 75, // (was 90 - mature faster)
  creatureReproductionMinEnergyRatio: 0.7, // (was 0.8 - easier to reproduce)
  creatureReproductionMinWaterRatio: 0.7, // (was 0.8 - easier to reproduce)
  creatureReproductionCooldown: 120, // (was 180 - faster reproduction cycle)
  creatureReproductionFailedCooldown: 15, // (was 20 - try again sooner)
  creatureReproductionFailedCostMultiplier: 0.4, // (was 0.5 - less penalty for failed mating)
  creatureReproductionRange: 2.5,

  // === CREATURES: SEX & PREGNANCY ===
  creatureSexEnabled: true,
  creaturePregnancyEnabled: true,
  creatureSexInitialSplitMode: 'exact',
  creatureConceptionChance: 0.6, // (was 0.5 - higher conception rate)
  creatureGestationTime: 45, // (was 60 - faster pregnancy)
  creatureGestationTraitEnabled: true,
  creaturePregnancyMetabolismMultiplier: 1.12, // (was 1.15 - less pregnancy cost)
  creaturePregnancyMoveSpeedMultiplier: 0.92, // (was 0.9 - less speed penalty)
  creaturePregnancyMiscarriageEnabled: true,
  creaturePregnancyMiscarriageEnergyRatio: 0.12, // (was 0.15 - miscarriage at lower energy)
  // Probability per second while below the miscarriage energy threshold.
  creaturePregnancyMiscarriageChancePerSecond: 0.35, // (was 0.4528 - lower miscarriage rate)

  // === CREATURES: MATE SEEKING ===
  creatureMateSeekingEnabled: true,
  creatureMateSeekRange: 28, // (was 25 - wider mate search)
  creatureMateSeekCommitTime: 0.8, // (was 1 - faster commitment)
  creatureReproductionRangeWhileSeeking: 7, // (was 6 - easier to complete mating)
  creatureMateSeekPriorityOverridesNeeds: false,

  // === CREATURES: OFFSPRING ===
  creatureBirthChildStartingMetersFastMultiplier: 0.88, // (was 0.85 - healthier fast-gestation babies)
  creatureBirthChildStartingMetersSlowMultiplier: 1.08, // (was 1.1 - slightly less bonus)
  creatureBirthChildStartingMetersFastIfMultiplierBelow: 0.9,
  creatureBirthChildStartingMetersSlowIfMultiplierAbove: 1.1,
  creatureReproductionEnergyCost: 0.18, // (was 0.2 - less costly reproduction)
  creatureReproductionWaterCost: 0.12, // (was 0.15 - less costly reproduction)
  creatureReproductionStaminaCost: 0.04, // (was 0.05)
  creatureOffspringEnergy: 0.65, // (was 0.6 - offspring start healthier)
  creatureOffspringWater: 0.65, // (was 0.6)
  creatureOffspringStamina: 0.65, // (was 0.6)
  creatureOffspringHp: 0.85, // (was 0.8)

  // === CREATURES: NEEDS & EATING ===
  creatureNeedSwitchMargin: 0.05,
  creatureDrinkThreshold: 0.75, // (was 0.8 - drink slightly less often)
  creatureDrinkAmount: 0.7, // (was 0.6 - drink faster)
  creatureEatThreshold: 0.75, // (was 0.8 - eat slightly less often)
  creatureEatAmount: 0.55, // (was 0.5 - eat slightly faster)
  creatureGrassEatMin: 0.04, // (was 0.05 - can eat scarcer grass)
  creatureBerryEatMin: 0.08, // (was 0.1 - can eat fewer berries)

  // === CREATURES: FOOD PROPERTIES ===
  creatureFoodProperties: {
    grass: { nutrition: 1, handling: 1, risk: 0.02 },
    berries: { nutrition: 1.3, handling: 1, risk: 0.04 }, // (was 1.2 - berries more nutritious)
    meat: { nutrition: 4.5, handling: 1.2, risk: 0.12 } // (was 4.0 - meat more nutritious)
  },
  creatureFoodEfficiency: {
    grass: 1,
    berries: 1,
    meat: 1
  },
  creatureTraitMultipliers: {
    square: {
      foodEfficiency: { berries: 1.3, grass: 0.75, meat: 0.65 } // (was 1.25 for berries)
    },
    triangle: {
      foodEfficiency: { meat: 1.3, grass: 0.7, berries: 0.7 } // (was 1.25 for meat)
    },
    circle: {
      foodEfficiency: { grass: 1.3, berries: 0.8, meat: 0.6 } // (was 1.25 for grass)
    },
    octagon: {
      foodEfficiency: { meat: 1.25, grass: 0.75, berries: 0.7 } // (was 1.2 for meat)
    }
  },

  // === GENETICS: GENOME DEFAULTS ===
  creatureGenomeDefaults: {
    default: {
      speed: 0.5,
      perceptionRange: 0.5,
      alertness: 0.5,
      reactionDelay: 0.5, // normalized 0-1
      basalEnergyDrain: 0.5,
      basalWaterDrain: 0.5,
      basalStaminaDrain: 0.5,
      sprintStartThreshold: 0.5,
      sprintStopThreshold: 0.5,
      sprintSpeedMultiplier: 0.5,
      sprintStaminaDrain: 0.5,
      staminaRegen: 0.5,
      drinkThreshold: 0.5,
      drinkAmount: 0.5,
      eatThreshold: 0.5,
      eatAmount: 0.5,
      grassEatMin: 0.5,
      berryEatMin: 0.5
    },
    square: {},
    triangle: {},
    circle: {},
    octagon: {}
  },
  creatureGenomeJitter: 0.1, // (was 0.08 - more initial variation)
  creatureGenomeMutationRate: 0.2, // (was 0.18 - slightly more mutations)
  creatureGenomeMutationStrength: 0.12, // (was 0.1 - stronger mutations for faster evolution)
  creatureGenomePleiotropyScale: 0.18,

  // === CREATURES: LIFESPAN ===
  creatureMaxAge: 540, // (was 600 - slightly shorter lifespan creates faster generations)
  creatureLifeStages: [
    {
      id: 'juvenile',
      label: 'Juvenile',
      minAge: 0, // seconds
      movementScale: 0.88, // (was 0.85 - juveniles slightly faster)
      metabolismScale: 0.88 // (was 0.9 - juveniles slightly more efficient)
    },
    {
      id: 'adult',
      label: 'Adult',
      minAge: 100, // (was 120 - reach adulthood faster)
      movementScale: 1,
      metabolismScale: 1
    },
    {
      id: 'elder',
      label: 'Elder',
      minAge: 280, // (was 300 - become elder slightly earlier)
      movementScale: 0.78, // (was 0.75 - elders slightly faster)
      metabolismScale: 1.08 // (was 1.1 - elders slightly more efficient)
    }
  ],
  creatureInspectRadius: 6
};

/**
 * Config metadata for UI generation.
 * Defines which config values are editable and how to display them.
 */
export const configMeta = {
  // Simulation
  ticksPerSecond: { label: 'Ticks/Second', min: 1, max: 120, step: 1, category: 'simulation' },

  // Creatures: Base Stats
  creatureCount: { label: 'Creature Count', min: 0, max: 500, step: 10, category: 'creatures' },
  creaturePredatorCount: {
    label: 'Predator Count',
    min: 0,
    max: 50,
    step: 1,
    category: 'creatures'
  },
  creatureBaseSpeed: { label: 'Base Speed', min: 1, max: 30, step: 1, category: 'creatures' },
  creatureBaseEnergy: { label: 'Base Energy', min: 0.1, max: 5, step: 0.1, category: 'creatures' },
  creatureBaseWater: { label: 'Base Water', min: 0.1, max: 5, step: 0.1, category: 'creatures' },

  // Creatures: Metabolism
  creatureBasalEnergyDrain: {
    label: 'Energy Drain/s',
    min: 0,
    max: 0.1,
    step: 0.001,
    category: 'metabolism'
  },
  creatureBasalWaterDrain: {
    label: 'Water Drain/s',
    min: 0,
    max: 0.1,
    step: 0.001,
    category: 'metabolism'
  },
  creatureSprintStaminaDrain: {
    label: 'Sprint Drain/s',
    min: 0,
    max: 1,
    step: 0.01,
    category: 'metabolism'
  },
  creatureStaminaRegen: {
    label: 'Stamina Regen/s',
    min: 0,
    max: 1,
    step: 0.01,
    category: 'metabolism'
  },
  creatureEatAmount: { label: 'Eat Amount/s', min: 0.1, max: 2, step: 0.1, category: 'metabolism' },
  creatureDrinkAmount: {
    label: 'Drink Amount/s',
    min: 0.1,
    max: 2,
    step: 0.1,
    category: 'metabolism'
  },

  // Predator Behavior
  creaturePredatorRestThreshold: {
    label: 'Rest When Energy >',
    min: 0.3,
    max: 1,
    step: 0.05,
    category: 'predator'
  },
  creaturePredatorHuntThreshold: {
    label: 'Hunt When Energy <',
    min: 0.1,
    max: 0.8,
    step: 0.05,
    category: 'predator'
  },
  creatureTargetingRange: {
    label: 'Targeting Range',
    min: 5,
    max: 30,
    step: 1,
    category: 'predator'
  },

  // Herding Behavior
  creatureHerdingStrength: {
    label: 'Herd Cohesion',
    min: 0,
    max: 1,
    step: 0.01,
    category: 'herding'
  },
  creatureHerdingAlignmentStrength: {
    label: 'Herd Alignment',
    min: 0,
    max: 1,
    step: 0.05,
    category: 'herding'
  },
  creatureHerdingThreatRange: {
    label: 'Threat Detect Range',
    min: 2,
    max: 20,
    step: 1,
    category: 'herding'
  },
  creatureHerdingThreatStrength: {
    label: 'Flee Strength',
    min: 0,
    max: 0.5,
    step: 0.05,
    category: 'herding'
  },
  creatureHerdingIdealDistance: {
    label: 'Herd Spacing',
    min: 2,
    max: 10,
    step: 0.5,
    category: 'herding'
  },

  // Movement Style
  creatureMaxTurnRateRadPerSecond: {
    label: 'Turn Rate (rad/s)',
    min: 1,
    max: 8,
    step: 0.5,
    category: 'movement'
  },
  creatureWanderRetargetTimeMin: {
    label: 'Wander Min (s)',
    min: 0.2,
    max: 3,
    step: 0.1,
    category: 'movement'
  },
  creatureWanderRetargetTimeMax: {
    label: 'Wander Max (s)',
    min: 1,
    max: 6,
    step: 0.5,
    category: 'movement'
  },

  creatureSearchRadiusMin: {
    label: 'Search Radius Min',
    min: 2,
    max: 60,
    step: 1,
    category: 'movement'
  },
  creatureSearchRadiusMax: {
    label: 'Search Radius Max',
    min: 10,
    max: 200,
    step: 5,
    category: 'movement'
  },
  creatureSearchRadiusGrowth: {
    label: 'Search Growth',
    min: 1.05,
    max: 2,
    step: 0.05,
    category: 'movement'
  },
  creatureSearchArriveDistance: {
    label: 'Search Arrive Dist',
    min: 0.5,
    max: 5,
    step: 0.25,
    category: 'movement'
  },

  // Pack Behavior
  creaturePackEnabled: {
    label: 'Pack Enabled',
    min: 0,
    max: 1,
    step: 1,
    category: 'predator'
  },
  creaturePredatorPatrolRadius: {
    label: 'Patrol Radius',
    min: 10,
    max: 50,
    step: 5,
    category: 'predator'
  },

  // Creatures: Reproduction
  creatureReproductionMinAge: {
    label: 'Min Repro Age (s)',
    min: 0,
    max: 300,
    step: 10,
    category: 'reproduction'
  },
  creatureReproductionCooldown: {
    label: 'Repro Cooldown (s)',
    min: 0,
    max: 600,
    step: 10,
    category: 'reproduction'
  },
  creatureGestationTime: {
    label: 'Gestation (s)',
    min: 10,
    max: 300,
    step: 5,
    category: 'reproduction'
  },
  creatureConceptionChance: {
    label: 'Conception %',
    min: 0,
    max: 1,
    step: 0.05,
    category: 'reproduction'
  },
  creaturePregnancyMiscarriageChancePerSecond: {
    label: 'Miscarriage chance/s',
    min: 0,
    max: 1,
    step: 0.05,
    category: 'reproduction'
  },

  // Creatures: Lifespan
  creatureMaxAge: { label: 'Max Age (s)', min: 60, max: 1800, step: 60, category: 'lifespan' },

  // Creatures: Chase
  creatureChaseStartThreshold: {
    label: 'Chase Start',
    min: 0,
    max: 1,
    step: 0.05,
    category: 'chase'
  },
  creatureChaseStopThreshold: {
    label: 'Chase Stop',
    min: 0,
    max: 1,
    step: 0.05,
    category: 'chase'
  },
  creatureChaseLoseTime: {
    label: 'Chase Lose (s)',
    min: 0.05,
    max: 1,
    step: 0.05,
    category: 'chase'
  },
  creatureChaseRestTime: {
    label: 'Chase Rest (s)',
    min: 0.05,
    max: 1,
    step: 0.05,
    category: 'chase'
  },

  // Plants & Carcasses
  grassRegrowthRate: {
    label: 'Grass Regrowth/s',
    min: 0,
    max: 0.1,
    step: 0.005,
    category: 'plants'
  },
  bushBerryRegenRate: { label: 'Berry Regen/s', min: 0, max: 1, step: 0.05, category: 'plants' },
  carcassBaseYield: {
    label: 'Carcass Meat Yield',
    min: 0.5,
    max: 10,
    step: 0.5,
    category: 'plants'
  },
  carcassDecayRate: { label: 'Carcass Decay/s', min: 0, max: 0.1, step: 0.005, category: 'plants' },

  // Genetics
  creatureGenomeMutationRate: {
    label: 'Mutation Rate',
    min: 0,
    max: 0.5,
    step: 0.01,
    category: 'genetics'
  },
  creatureGenomeMutationStrength: {
    label: 'Mutation Strength',
    min: 0,
    max: 0.3,
    step: 0.01,
    category: 'genetics'
  }
};
