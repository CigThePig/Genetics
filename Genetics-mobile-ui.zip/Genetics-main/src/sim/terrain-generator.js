/**
 * Terrain Generator
 * Re-exports enhanced terrain generation with noise-based organic terrain
 */

export { generateTerrain, generateTerrainLegacy } from './terrain-generator-enhanced.js';
