Active track: Maintenance — Performance Profiler Panel
Path: tracks/2026-02-01-track-maintenance-per-species-metrics/
Current phase: Phase 1 — Perf sampler, instrumentation, and Performance panel (verification pending)
Next task: Resolve prettier warnings, rerun npm run verify, and complete manual perf panel checklist.
Last updated: 2026-02-01
Notes: Maintenance work requested to add performance profiler panel and fix FPS overlay duplication.
